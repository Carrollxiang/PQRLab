import setuptools

setuptools.setup(
    name="devices",
    version="1.0",
    author="张宽",
    description="",
    long_description="devices Module",
    long_description_content_type="devices",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)

# setuptools.setup(
#     name="experiment",
#     version="1.0",
#     author="张宽",
#     description="",
#     long_description="experiment Module",
#     long_description_content_type="experiment",
#     url="",
#     packages=setuptools.find_packages(),
#     classifiers=[
#         "Programming Language :: Python :: 3",
#         "License :: OSI Approved :: MIT License",
#         "Operating System :: OS Independent",
#     ],
# )
